defmodule PhoenixKitWeb.Plugs.EnsureOAuthScheme do
  @moduledoc """
  Ensures correct HTTPS scheme for OAuth callback URL generation behind reverse proxies.

  This plug checks (in order):
  1. `X-Forwarded-Proto` header (nginx/apache standard)
  2. `site_url` setting from database (preferred - configured via admin interface)
  3. Explicit `:phoenix_kit, :oauth_base_url` config (fallback)
  4. Endpoint URL configuration (last resort)

  ## Usage

  Automatically included in OAuth controller. No manual setup required.

  ## Recommended Configuration

  Set the site URL via the PhoenixKit admin interface:
  - Navigate to Settings → General
  - Set "Site URL" to your domain (e.g., "https://example.com")
  - This will be used automatically for OAuth callback URLs

  ## Alternative Configuration (Optional)

  If database settings are not available, use config file:

      config :phoenix_kit,
        oauth_base_url: "https://example.com"

  """

  import Plug.Conn

  def init(opts), do: opts

  def call(conn, _opts) do
    cond do
      # 1. Check X-Forwarded-Proto header (standard for nginx/apache)
      forwarded_proto = get_forwarded_proto(conn) ->
        apply_scheme(conn, forwarded_proto)

      # 2. Check site_url from database settings (preferred for admin-configured deployments)
      site_url = get_site_url_from_settings() ->
        apply_base_url(conn, site_url)

      # 3. Check explicit oauth_base_url config (fallback)
      base_url = Application.get_env(:phoenix_kit, :oauth_base_url) ->
        apply_base_url(conn, base_url)

      # 4. Check endpoint URL config (last resort)
      true ->
        apply_endpoint_config(conn)
    end
  end

  defp get_forwarded_proto(conn) do
    case get_req_header(conn, "x-forwarded-proto") do
      [proto | _] when proto in ["https", "http"] -> proto
      _ -> nil
    end
  end

  defp apply_scheme(conn, "https"), do: %{conn | scheme: :https, port: 443}
  defp apply_scheme(conn, _), do: conn

  defp apply_base_url(conn, base_url) when is_binary(base_url) do
    uri = URI.parse(base_url)

    %{
      conn
      | scheme: parse_scheme(uri.scheme),
        host: uri.host || conn.host,
        port: uri.port || default_port(uri.scheme)
    }
  end

  defp apply_endpoint_config(conn) do
    endpoint = Phoenix.Controller.endpoint_module(conn)

    with endpoint when not is_nil(endpoint) <- endpoint,
         url_config when is_list(url_config) <- get_endpoint_url_config(endpoint),
         "https" <- Keyword.get(url_config, :scheme) do
      %{conn | scheme: :https, port: 443}
    else
      _ -> conn
    end
  rescue
    KeyError -> conn
  end

  defp get_endpoint_url_config(endpoint_module) do
    # Safely extract otp_app attribute
    otp_app =
      case endpoint_module.__info__(:attributes)[:otp_app] do
        [app | _] when is_atom(app) -> app
        _ -> nil
      end

    case Application.get_env(otp_app, endpoint_module) do
      nil -> []
      config -> Keyword.get(config, :url, [])
    end
  end

  defp parse_scheme("https"), do: :https
  defp parse_scheme("http"), do: :http
  defp parse_scheme(_), do: :https

  defp default_port("https"), do: 443
  defp default_port("http"), do: 80
  defp default_port(_), do: 443

  # Get site_url from database settings
  # This allows admins to configure the OAuth callback URL via the web admin interface
  defp get_site_url_from_settings do
    try do
      if Code.ensure_loaded?(PhoenixKit.Settings) do
        case PhoenixKit.Settings.get_setting("site_url") do
          nil -> nil
          "" -> nil
          url when is_binary(url) -> String.trim(url)
        end
      else
        nil
      end
    rescue
      _ -> nil
    end
  end
end
